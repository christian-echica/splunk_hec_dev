import base64
import requests
import gzip
import boto3
import json 

def lambda_handler(event, context):
    try:
        payload = base64.b64decode(event['awslogs']['data'])
        decompressed = gzip.decompress(payload)
        result = json.loads(decompressed)
        print("Event Data:", json.dumps(result))

        # Set up the HTTP Event Collector endpoint
        splunk_endpoint = "http://ec2-50-19-73-215.compute-1.amazonaws.com:8088/services/collector/event"
        splunk_token = "2e8b9b70-a552-482d-88e4-9eaba1e3ae96"
        # Retrieve the Splunk token from the AWS Secret Manager
        # secret_manager = boto3.client("secretsmanager")
        # response = secret_manager.get_secret_value(
        #     SecretId="your-secret-id"
        # )
        # splunk_token = response["SecretString"]

        # Make POST data
        post_data = {}
        post_data['event'] = result
        post_data['sourcetype'] = 'aws_lambda'
        # Send the data to Splunk using the HTTP Event Collector
        print("Sending data to Splunk HEC...")
        r = requests.post(
            splunk_endpoint,
            headers={
                "Authorization": "Splunk " + splunk_token
            },
            json=post_data,
            verify = False
        )
        print("Data sent to Splunk HEC.")
        if r.status_code != 200:
            print("Error sending data to Splunk HEC. Status code:", r.status_code, ", Message:", r.text)
    except KeyError:
        print("Test button clicked in Lambda Console. No input data available.")
    except Exception as e:
        print("Error:", str(e))